from flask import Flask
from flask import jsonify
import requests
from flask import render_template,redirect,url_for
from flask import request


###### App setup

app = Flask(__name__)
response = requests.get("https://www.10bis.co.il/NextApi/GetRestaurantMenu?restaurantId=19156")
response.json()

@app.route('/', methods=['GET'])
def home():
    return 'menu'

@app.route('/drinks', methods=['GET'])
def get_drinks():
    drinks=[]
    parameters = {"categoryName": "שתייה"}
    response = requests.get("https://www.10bis.co.il/NextApi/GetRestaurantMenu?restaurantId=19156",params=parameters)
    for d in response.json()['Data']['categoriesList']:
        drinks.append(d['dishList'])

    return jsonify({
                'success': 'True',
                'data': drinks[0]
            })

@app.route('/drink/<int:id>', methods=['GET'])
def get_a_drink(id):
    drinks=[]
    parameters = {"categoryName": "שתייה"}
    response = requests.get("https://www.10bis.co.il/NextApi/GetRestaurantMenu?restaurantId=19156",params=parameters)
    for d in response.json()['Data']['categoriesList']:
        if d['dishList'][0]['dishId']==id :
            drinks.append(d['dishList'])

    return jsonify({
                'success': 'True',
                'dishId': drinks['dishList']['dishId'],
                'dishName': drinks['dishList']['dishName'],
                'dishDescription': drinks['dishList']['dishDescription'],
                'dishPrice': drinks['dishList']['dishPrice']
            })

@app.route('/pizzas', methods=['GET'])
def get_pizzas():
    pizzas=[]
    parameters = {"categoryName": "פיצות"}
    response = requests.get("https://www.10bis.co.il/NextApi/GetRestaurantMenu?restaurantId=19156",params=parameters)
    for p in response.json()['Data']['categoriesList']:
        pizzas.append(p['dishList'])

    return jsonify({
                'success': 'True',
                'data': pizzas[0]
            })

@app.route('/pizzas/<int:id>', methods=['GET'])
def get_a_pizza(id):
    pizza=[]
    parameters = {"categoryName": "פיצות"}
    response = requests.get("https://www.10bis.co.il/NextApi/GetRestaurantMenu?restaurantId=19156",params=parameters)
    for d in response.json()['Data']['categoriesList']:
        if d['dishList'][0]['dishId']==id :
            pizza.append(d['dishList'])

    return jsonify({
                'success': 'True',
                'dishId': pizza['dishList']['dishId'],
                'dishName': pizza['dishList']['dishName'],
                'dishDescription': pizza['dishList']['dishDescription'],
                'dishPrice': pizza['dishList']['dishPrice']
            })

@app.route('/order', methods=['GET','POST'])
def make_an_order():
    if request.method == 'POST':
        id_1 = request.form['drink1']
        id_2 = request.form['drink1']
        id_3 = request.form['pizza1']
        id_4 = request.form['pizza2']
        id_5 = request.form['dessert1']
        id_6 = request.form['dessert2']
        total_price = 0
        response = requests.get("https://www.10bis.co.il/NextApi/GetRestaurantMenu?restaurantId=19156")
        dishes=[]
        for c in response.json()['Data']['categoriesList']:
            dishes.append(c['dishList'])
            for dish in dishes:
                if dish[0]['dishId'] == id_1 or dish[0]['dishId'] == id_2 or dish[0]['dishId'] == id_3 or dish[0]['dishId'] == id_4 or dish[0]['dishId'] == id_5 or dish[0]['dishId'] == id_6:
                    total_price = total_price + dish[0]['dishPrice']
        return jsonify({
            'price': total_price
            })
    return render_template('order.html', req_method=request.method, action="insert")

# #

if __name__ == '__main__':
    app.run(debug=True)
